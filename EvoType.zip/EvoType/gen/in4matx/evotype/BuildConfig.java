/** Automatically generated file. DO NOT MODIFY */
package in4matx.evotype;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}